

var fw = {}; // globally available object


(function () {  // This is an IIFE, an Immediately Invoked Function Expression
    //alert("I am an IIFE!");

    fw.createFilter = function (filterId, tableId, num) {
        var filt = document.createElement("div");
        dataList.innerHTML = "<input type='text' id='filterId' onkeyup='findFilter(filterId, tableId, num)' placeholder='Search for names..'>";
        
        // create a filter with passed in filterId (Id of the input box) and tableId (which table it is filtering) and num (filter by which column)

    };


    fw.findFilter = function (filterId, tableId, num) {

         // Declare variables 
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("filterId");
        filter = input.value.toUpperCase();
        table = document.getElementById("tableId");
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, and hide those who don't match the search query
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[num];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }    
        }
    };
    
    
    fw.modalImage = function (imageId) {            //image needs an ID to make it modal
        
        var modal = document.createElement("div");
        modal.id = "myModal";
        modal.class = "modal";
        
        modal.innerHTML = "<span class='close'>&times;</span>";
        modal.innerHTML += "<img class='modal-content' id='img01'>" ;  
        modal.innerHTML += "<div id='caption'></div>" ;
        modal.innerHTML += "<span class='close'>&times;</span>";
        
        
        // Get the modal
        var modal = document.getElementById('myModal');

        // Get the image and insert it inside the modal - use its "alt" text as a caption
        var img = document.getElementById(imageId);
        var modalImg = document.getElementById("img01");
        var captionText = document.getElementById("caption");
        
        img.onclick = function(){
            modal.style.display = "block";
            modalImg.src = this.src;
            captionText.innerHTML = this.alt;
        };

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() { 
            modal.style.display = "none";
        };

        
    };

}());  // the end of the IIFE





